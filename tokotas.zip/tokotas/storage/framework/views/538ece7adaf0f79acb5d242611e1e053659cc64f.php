<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
       <div class="col-md-12 mb-5">
        <img src="<?php echo e(url('images/logo.jpg')); ?>" width="40%" height="40%" style="display: block; margin: auto;"></a> 
           </div>
       <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="card">
                <img class="center-fit" src='uploads/tas2.jpg' width=250>
                <div class="card-body">
                    <h3 class="card-title"><?php echo e($barang->nama_barang); ?> </h3>
                    <p class="card-text">
                    <strong>Harga :</strong>  Rp. <?php echo e(number_format($barang->harga)); ?>

                    <br>
                    <strong>Stok :</strong> <?php echo e($barang->stok); ?>

                    <br>
                    <strong>Keterangan :</strong> <br>
                    <?php echo e($barang->keterangan); ?>

                    </p>
                    
                    <h3> <a href="/pesan/<?php echo e($barang->id); ?>" class="btn btn-primary"><i class="fa fa-shopping-cart">
                    </i> Pesan DISINI!</a></h3>

                </div>
            </div>
        </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tokotas\resources\views/home.blade.php ENDPATH**/ ?>